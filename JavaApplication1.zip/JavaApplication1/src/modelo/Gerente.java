
package modelo;

public class Gerente extends Funcionario {
    
    private int senha;
    private int numFuncGerenciados;
    public double bonificacao;
    
    
    public double getBonificacao() {
        return this.salario* 0.15;
    }

    @Override
    public String  getNome(){
        return this.nome+" (Gerente)";
        
    }

    public int getSenha() {
        return senha;
    }

    public void setSenha(int senha) {
        this.senha = senha;
    }

    public int getNumFuncGerenciados() {
        return numFuncGerenciados;
    }

    public void setNumFuncGerenciados(int numFuncGerenciados) {
        this.numFuncGerenciados = numFuncGerenciados;
    }
    
}
