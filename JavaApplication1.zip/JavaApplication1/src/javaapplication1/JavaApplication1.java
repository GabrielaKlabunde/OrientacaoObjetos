
package javaapplication1;

import modelo.Funcionario;
import modelo.Gerente;

public class JavaApplication1 {

    public static void main(String[] args) { 
        //1- pedir pacote modelo
        //2- dentro de modelo criar uma classe FUNCIONARIO
        //3- "inserir codigo" "GETTER E SETTER", selecionar todas as variaveis
        //4- criar "classe java" == gerente.
        //5- dentro da classe gerente, extender: public class Gerente extends Funcionario
        //6-criar variaveis senha e numFuncGerenciados na classe Gerente no PRIVATE
        
        //cria o funcionario normal
        Funcionario f = new Funcionario();
        f.setNome("Gabriela");
        f.setCpf("11747789939");
        f.setSalario(1000);
        
        //cria um gerente
        Gerente g = new Gerente();
        g.setNome("Fabiana");
        g.setCpf("23356674312");
        g.setNumFuncGerenciados(10);
        g.setSalario(1000);
        
        
        //FUNCIONARIO NORMAL
        System.out.println("Dados do funcionário:");
        System.out.println("Nome: "+f.getNome());
        System.out.println("CPF: "+f.getCpf());
        System.out.println("Bonificação: "+f.getBonificacao());
        System.out.println("Salário: "+f.getSalario());
        System.out.println("------------------");
        
        //GERENTE
        System.out.println("Dados do Gerente:");
        System.out.println("Nome: "+g.getNome());
        System.out.println("CPF: "+g.getCpf());
        System.out.println("Bonificação: "+g.getBonificacao());
        System.out.println("Salário: "+g.getSalario());
        System.out.println("Número funcionários: "+g.getNumFuncGerenciados());
        
        Funcionario gerenteTeste = g;
        
        System.out.println("------------------");
        System.out.println("Gerente teste");
        System.out.println(gerenteTeste.getNome());
        System.out.println(gerenteTeste.getCpf());
    }
    
}
